.. Sokoban documentation master file, created by
   sphinx-quickstart on Wed May 13 15:33:39 2020.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Sokoban's documentation!
===================================

.. image::  images/player.png
   :align:  right
.. toctree::
   :maxdepth: 2
   :caption: Contents:

   documentation
   module

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
