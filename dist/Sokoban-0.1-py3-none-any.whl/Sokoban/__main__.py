"""__main__.py
==================================
Script for launching application
"""

import Sokoban

Sokoban.init()
Sokoban.run()
