from Sokoban import BaseApp

BaseApp.init()
BaseApp.run()
